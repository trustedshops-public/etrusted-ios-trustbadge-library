//
//  Trustbadge.h
//  Trustbadge
//
//  Created by Prem Pratap Singh on 07/11/22.
//

#import <Foundation/Foundation.h>

//! Project version number for Trustbadge.
FOUNDATION_EXPORT double TrustbadgeVersionNumber;

//! Project version string for Trustbadge.
FOUNDATION_EXPORT const unsigned char TrustbadgeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Trustbadge/PublicHeader.h>


